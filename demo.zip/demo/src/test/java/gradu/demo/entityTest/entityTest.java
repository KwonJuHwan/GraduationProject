package gradu.demo.entityTest;

import gradu.domain.Review;
import gradu.domain.ReviewService;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringRunner.class)
@SpringBootTest
public class entityTest {
    @Autowired
    ReviewService reviewService;
    @Test
    @Transactional
    public void testReview(){
        Review review = new Review();
        review.setReviewTitle("hello");
        review.setReviewContents("Amazing Culture");

        Review review1 = reviewService.insertReview(review);
        Assertions.assertThat(review1).isEqualTo(review);
    }
}
